def translate(code, source, target):

    # Python -> Java
    if source == "Python" and target == "Java":
        return code.replace("print(", "System.out.println(")

    # Python -> C
    elif source == "Python" and target == "C":
        return code.replace("print(", "printf(")

    # Python -> C++
    elif source == "Python" and target == "C++":
        return code.replace("print(", "cout << ")

    # C -> C++
    elif source == "C" and target == "C++":

        translated = code

        translated = translated.replace(
            "#include <stdio.h>",
            "#include <iostream>\nusing namespace std;"
        )

        translated = translated.replace(
            "printf(",
            "cout << "
        )

        return translated

    # C -> Python
    elif source == "C" and target == "Python":

        translated = code

        translated = translated.replace("#include <stdio.h>", "")
        translated = translated.replace("int main() {", "")
        translated = translated.replace("return 0;", "")
        translated = translated.replace("{", "")
        translated = translated.replace("}", "")
        translated = translated.replace("printf(", "print(")

        return translated

    # C -> Java
    elif source == "C" and target == "Java":

        translated = code

        translated = translated.replace(
            "#include <stdio.h>",
            "public class Main {\n    public static void main(String[] args) {"
        )

        translated = translated.replace(
            "int main() {",
            ""
        )

        translated = translated.replace(
            "printf(",
            "System.out.println("
        )

        translated = translated.replace(
            "return 0;",
            ""
        )

        translated += "\n    }\n}"

        return translated

    # Java -> Python
    elif source == "Java" and target == "Python":

        translated = code

        translated = translated.replace(
            "System.out.println(",
            "print("
        )

        return translated

    # C++ -> Python
    elif source == "C++" and target == "Python":

        translated = code

        translated = translated.replace(
            "cout << ",
            "print("
        )

        translated = translated.replace(
            " << endl;",
            ")"
        )

        return translated

    elif source == target:
        return code

    return f"Translation from {source} to {target} is under development."