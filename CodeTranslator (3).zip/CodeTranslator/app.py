from flask import Flask, render_template, request
from translator import translate

app = Flask(__name__)

@app.route("/", methods=["GET", "POST"])
def home():

    translated_code = ""
    source = "Python"
    target = "Java"

    if request.method == "POST":
        code = request.form["code"]
        source = request.form["source"]
        target = request.form["target"]

        translated_code = translate(code, source, target)

    return render_template(
        "index.html",
        translated_code=translated_code,
        source=source,
        target=target
    )

if __name__ == "__main__":
    app.run(debug=True)